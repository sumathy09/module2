package com.capgemini.spring.dao;
 
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
  
import com.capgemini.spring.entity.CustomerEntity;
 
import com.capgemini.spring.exception.CustomerException;
import com.capgemini.spring.model.Customer;
import com.capgemini.spring.model.Transaction;
 
 
@Repository
public class BankDAOImpl implements IBankDAO {
	Customer c=new Customer();
	double balance;
	@PersistenceContext
	private EntityManager entityManager; 
	@Override
	public Integer createAccount(CustomerEntity cust) throws CustomerException {
		try {
			entityManager.persist(cust); 
			return 1;
		} catch (PersistenceException e)  {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();

		}
		   
	}


	@Override
	public List<CustomerEntity> getAlluserDetails() throws CustomerException{
		String sql="From CustomerEntity";
		try {
			 
			Query query=entityManager.createQuery(sql);
			List<CustomerEntity> customerEntityList=query.getResultList();			
		 
			return customerEntityList;
		}catch(PersistenceException e) {			
			throw new CustomerException(e.getMessage());
		}catch(Exception e) {	
			throw new CustomerException(e.getMessage());
		}finally {
			entityManager.close();

		}
		 
	}


	@Override
	public double showBalance(Integer accNo,Integer pin) throws CustomerException {
		double balance;
		try { 
        	c = entityManager.find(Customer.class, accNo);
        	c = entityManager.find(Customer.class, pin);
        	
			balance = c.getBalance();
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();

		} 
		return balance;
		 
	}


	@Override
	public Integer validAccount(Integer id) throws CustomerException {
		try{
			int equal = 0;
			 
		if((entityManager.find(Customer.class, id))!=null)
			 equal=id;
		 
		return equal;
		}catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}  	finally {
			entityManager.close();

		}
	}


	@Override
	public Integer validPin(Integer pin) throws CustomerException {
		try{
			int equal = 0;
			 
		if((entityManager.find(Customer.class, pin))!=null)
			 equal=pin;
		 
		return equal;
		}catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}  finally {
			entityManager.close();

		}
		
	}


	@Override
	public double deposit(Integer accNo, double deposit)
			throws CustomerException {
		try {
			 
			c = entityManager.find(Customer.class, accNo);
			balance = c.getBalance();
			balance = balance + deposit; 
			c.setBalance(balance);
			
			Transaction trans=new Transaction();
			trans.setTransType("deposit");
			trans.setTransHistory(deposit);
			trans.setCus(c);
			entityManager.merge(c);
			entityManager.persist(trans);
			 
			return balance;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();

		}
	}


	@Override
	public double withdraw(Integer accNo, double withdraw)
			throws CustomerException {
		try {
			c = entityManager.find(Customer.class, accNo);
			balance = c.getBalance();
			balance = balance - withdraw;
			c.setBalance(balance);
			Transaction tran=new Transaction();
			tran.setTransType("withdraw");
			tran.setTransHistory(withdraw);
			tran.setCus(c);
			entityManager.merge(c); 
			entityManager.persist(tran);
			return balance;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}
	}

	 

	
}
