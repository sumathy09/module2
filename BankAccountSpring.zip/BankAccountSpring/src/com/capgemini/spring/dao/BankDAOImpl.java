package com.capgemini.spring.dao;
 
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import org.springframework.stereotype.Repository;
import com.capgemini.spring.entity.CustomerEntity;
import com.capgemini.spring.exception.CustomerException;
 
@Repository
public class BankDAOImpl implements IBankDAO {
	@PersistenceContext
	private EntityManager entityManager;
	//CustomerEntity c = new CustomerEntity();
	
	 
	@Override
	public CustomerEntity createAccount(CustomerEntity cust) throws CustomerException {
		try {
			//entityManager = JPAUtil.getEntityManager();
			//entityManager.getTransaction().begin();
			//cust.setAccNo(null);
			entityManager.persist(cust);
			//entityManager.getTransaction().commit();
			return cust;
		} catch (PersistenceException e)  {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		  finally {
			//entityManager.close();
		}
		//return cust;
	}

	 

	
}
