 package com.capgemini.spring.dao;

 

import com.capgemini.spring.entity.CustomerEntity;
import com.capgemini.spring.exception.CustomerException;
 
 

public interface IBankDAO {

    CustomerEntity createAccount(CustomerEntity cust) throws CustomerException ;
    
     
}