 package com.capgemini.spring.service;
 
import org.springframework.stereotype.Service;

import com.capgemini.spring.dao.BankDAOImpl;
import com.capgemini.spring.dao.IBankDAO;
import com.capgemini.spring.entity.CustomerEntity;
import com.capgemini.spring.exception.CustomerException;
 
 
@Service
public class BankServiceImpl implements IBankService {
     
    IBankDAO dao = new BankDAOImpl();
     

    @Override
    public CustomerEntity createAccount(CustomerEntity cust)  throws CustomerException  {
        return dao.createAccount(cust);
    }

   

    
}