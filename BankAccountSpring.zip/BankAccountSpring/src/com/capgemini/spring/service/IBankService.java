package com.capgemini.spring.service;
 
import com.capgemini.spring.entity.CustomerEntity;
import com.capgemini.spring.exception.CustomerException;
 

public interface IBankService {
	  CustomerEntity createAccount(CustomerEntity cust)  throws CustomerException ;
	     
}
