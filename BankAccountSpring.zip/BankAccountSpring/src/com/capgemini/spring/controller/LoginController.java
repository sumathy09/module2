package com.capgemini.spring.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.capgemini.spring.model.Login;
 

@Controller
@RequestMapping(value="/login")
public class LoginController {
	
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView viewLogin() {
		return new ModelAndView("login","login",new Login());
	}
	
	@RequestMapping(value="/verify", method=RequestMethod.POST)
	public String doLogin( @Valid @ModelAttribute("login") Login login,
			BindingResult result, HttpServletRequest request, Model model){
		try {
			if(result.hasErrors()) {
				List<ObjectError> errorList=result.getAllErrors();
				System.out.println(errorList);
				return "login";
			}else {
				if(isValidCredential(login)) {
					HttpSession session= request.getSession();
					session.setAttribute("userid", login.getUserId());
					return "main_menu";
				}else{
					model.addAttribute("message","Invalid Credentials");
					return "status";
				}
			}
		} catch (Exception e) {			
			e.printStackTrace();
		}		
		model.addAttribute("status","Invalid Credentials");
		return "statuslog";
	}

	private boolean isValidCredential(Login login) {
		if("admin".equals(login.getUserId()) && "admin@123".equals(login.getPassword())) {
			return true;
		}
		return false;
	}
}
