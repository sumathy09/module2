package com.capgemini.spring.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.spring.exception.CustomerException; 
import com.capgemini.spring.model.Customer;
import com.capgemini.spring.service.IBankService;
 

@Controller
@RequestMapping(value="/customer")
public class CustomerController {
	@Autowired
	IBankService service;
	@RequestMapping(value="/newuser",method=RequestMethod.GET)
	public ModelAndView showUserForm() {
		return new ModelAndView("add_user","customer",new Customer());
	}
	 
		
		@RequestMapping(value="/register", method=RequestMethod.POST)
		public ModelAndView processUserForm( @Valid @ModelAttribute("customer") Customer customer,
				BindingResult result){
			
			try {
				if(result.hasErrors()) {
					List<ObjectError> errorList=result.getAllErrors();
					System.out.println(errorList);
					return new ModelAndView("add_user","customer",new Customer());
				}else {
					//System.out.println(user.getUsername()+","+user.getBirthdate());
					//persist into database, call service class method
					 
					com.capgemini.spring.entity.CustomerEntity cust=new com.capgemini.spring.entity.CustomerEntity();
					populateCust(cust,customer);
					Integer n=service.createAccount(cust);
					if(n>0) {
						return new ModelAndView("status","status","Customer Registered Successfully");
					}else {
						return new ModelAndView("status","status","Unable to add customer to database");
					}
				}
			} catch (Exception e) {	
				e.printStackTrace();
				return new ModelAndView("status","status",e.getMessage()); 
			}		
			
		}
 
		private void populateCust(com.capgemini.spring.entity.CustomerEntity cust,Customer customer) {
			
			 cust.setName(customer.getName());
			 cust.setAathar(customer.getAathar());
			 cust.setAddress(customer.getAddress());
			 cust.setBirthDate(customer.getBirthDate());
			 cust.setBalance(customer.getBalance());
			 cust.setEmailId(customer.getEmailId());
			 cust.setPhoneNo(customer.getPhoneNo());
			 cust.setAccNo(customer.getAccNo());
			 cust.setPin(customer.getPin());
		} 


@RequestMapping(value="/allusers", method=RequestMethod.GET)
public ModelAndView getAllCustomerDetails() {
	try {
		List<Customer> userList=service.getAllUserDetails();
		if(userList.size()!=0) {				
			return new ModelAndView("all_users","customerList",userList);
		}else {
			return new ModelAndView("status","status","No users in database");
		}
	}catch(CustomerException e) {
		e.printStackTrace();
		return new ModelAndView("status","status",e.getMessage());
	}
}
 
@RequestMapping(value="/account", method=RequestMethod.GET)
public ModelAndView accountNumber(@RequestParam(value="accNo") Integer accNo) {
	try {
		Integer n=service.validAccount(accNo);
		if(n>0) {				
			return new ModelAndView("account_valid","account",n); 
		}else {
			return new ModelAndView("status","status","Account number does not exists");
		}
	}catch(CustomerException e) {
		e.printStackTrace();
		return new ModelAndView("status","status",e.getMessage());
	}
}

@RequestMapping(value="/pin", method=RequestMethod.GET)

public ModelAndView pinNumber(@RequestParam(value="pin") Integer pin) {
	try {
		Integer n=service.validPin(pin);
		if(n>0) {				
			return new ModelAndView("pin_valid","pin",n); 
		}else {
			return new ModelAndView("status","status","Enter the correct pin number");
		}
	}catch(CustomerException e) {
		e.printStackTrace();
		return new ModelAndView("status","status",e.getMessage());
	}
}

@RequestMapping(value="/balance",method=RequestMethod.GET)

public ModelAndView showBalance() {
	Customer c=new Customer();
	return new ModelAndView("account_pin","customer",c);
}
@RequestMapping(value="/reg",method=RequestMethod.POST)
public ModelAndView processBalance( @RequestParam(value="accNo") Integer accNo, @RequestParam(value="pin") Integer pin) {
	try{
		Double balance=service.showBalance(accNo,pin);
		
			return new ModelAndView("Show_balance","balance",balance);	
	
	}catch(CustomerException e){
		e.printStackTrace();
		return new ModelAndView("status","status",e.getMessage());	
	}
 
}
}