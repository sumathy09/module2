package com.capgemini.spring.controller;

import java.util.List;

import javax.validation.Valid;

 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;



import com.capgemini.spring.entity.CustomerEntity;
 
import com.capgemini.spring.model.Customer;
import com.capgemini.spring.service.IBankService;

@Controller
@RequestMapping(value="/customer")
public class CustomerController {
	@Autowired
	IBankService service;
	@RequestMapping(value="/newuser",method=RequestMethod.GET)
	public ModelAndView showUserForm() {
		return new ModelAndView("add_user","customer",new Customer());
	}
	 
		
		@RequestMapping(value="/register", method=RequestMethod.POST)
		public ModelAndView processUserForm( @Valid @ModelAttribute("customer") Customer customer,
				BindingResult result){
			
			try {
				if(result.hasErrors()) {
					List<ObjectError> errorList=result.getAllErrors();
					System.out.println(errorList);
					return new ModelAndView("add_user","customer",new CustomerEntity());
				}else {
					//System.out.println(user.getUsername()+","+user.getBirthdate());
					//persist into database, call service class method
					 
					com.capgemini.spring.entity.CustomerEntity cust=new com.capgemini.spring.entity.CustomerEntity();
					populateCust(cust,customer);
					CustomerEntity n=service.createAccount(cust);
					if(n!=null) {
						return new ModelAndView("status","status","User added to database");
					}else {
						return new ModelAndView("status","status","Unable to add user to database");
					}
				}
			} catch (Exception e) {	
				e.printStackTrace();
				return new ModelAndView("status","status",e.getMessage()); 
			}		
			
		}
 
		private void populateCust(com.capgemini.spring.entity.CustomerEntity cust,Customer customer) {
			
			 cust.setName(customer.getName());
			 cust.setAathar(customer.getAathar());
			 cust.setAddress(customer.getAddress());
			 cust.setBirthdate(customer.getBirthdate());
			 cust.setBalance(customer.getBalance());
			 cust.setEmailId(customer.getEmailId());
			 cust.setPhoneNo(customer.getPhoneNo());
			 cust.setAccNo(customer.getAccNo());
			
		} 
}
