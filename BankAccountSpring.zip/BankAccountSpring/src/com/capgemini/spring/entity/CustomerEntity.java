package com.capgemini.spring.entity;
 
 
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Table(name="customer_entity")
@Entity
public class CustomerEntity {
	@Id
	private Integer accNo;
	private String name;
	private String phoneNo;
	private String address;
	private String aathar;
    private Double balance;
    private String birthdate;
    private String emailId;
    
    @OneToMany(mappedBy="cus",cascade=CascadeType.ALL)
   	private List<Transaction> customer = new ArrayList<Transaction>();
  
    public List<Transaction> getCustomer() {
   		return customer;
   	}

   	public void setCustomer(List<Transaction> customer) {
   		this.customer = customer;
   	}
    public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
 
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAathar() {
		return aathar;
	}

	public void setAathar(String aathar) {
		this.aathar = aathar;
	}

	 
	public Integer getAccNo() {
		return accNo;
	}

	public void setAccNo(Integer accNo) {
		this.accNo = accNo;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [accNo=" + accNo + ", name=" + name + ", phoneNo="
				+ phoneNo + ", address=" + address + ", aathar=" + aathar
				+ ", balance=" + balance + ", birthdate=" + birthdate
				+ ", emailId=" + emailId + " ]";
	}

	 
	

}



 