package com.capgemini.spring.model;

 
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.capgemini.spring.entity.CustomerEntity;
 
@Entity
@Table(name="print_transaction")
public class Transaction {
	@Override
	public String toString() {
		return "Transaction [transNo=" + transNo + ", transType=" + transType
				+ ", amount=" + transHistory + ", cus=" + cus + "]";
	}

	@Id
	private int transNo;
	
	String transType;
   double transHistory;
	

	@ManyToOne
	@JoinColumn(name="accNo")
	CustomerEntity cus=new CustomerEntity();
	
	
	 
	public int getTransNo() {
		return transNo;
	}

	public void setTransNo(int transNo) {
		this.transNo = transNo;
	}

	

	public CustomerEntity getCus() {
		return cus;
	}

	public void setCus(CustomerEntity cus) {
		this.cus = cus;
	}
	 

	public double getTransHistory() {
		return transHistory;
	}

	public void setTransHistory(double transHistory) {
		this.transHistory = transHistory;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}
	 
	 
	

	 
	 
	 
}
