package com.capgemini.spring.model;

import javax.persistence.Id;

public class Customer {
	@Id
	private int accNo;
	private String name;
	private String phoneNo;
	private String address;
	private String aathar;
    private double balance;
    private String birthdate;
    private String emailId;
	 
    public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int accNo, String name, String phoneNo, String address,
			String aathar, double balance, String birthdate, String emailId) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.phoneNo = phoneNo;
		this.address = address;
		this.aathar = aathar;
		this.balance = balance;
		this.birthdate = birthdate;
		this.emailId = emailId;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
 
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAathar() {
		return aathar;
	}

	public void setAathar(String aathar) {
		this.aathar = aathar;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo2) {
		this.accNo = accNo2;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	

	@Override
	public String toString() {
		return "Customer [accNo=" + accNo + ", name=" + name + ", phoneNo="
				+ phoneNo + ", address=" + address + ", aathar=" + aathar
				+ ", balance=" + balance + ", birthdate=" + birthdate
				+ ", emailId=" + emailId + " ]";
	}

	 
	
}
