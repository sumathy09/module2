package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.HelloWorld;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("test.xml");
		HelloWorld obj1=(HelloWorld) context.getBean("helloWorldBean");
		System.out.println(obj1.getMessage());
		/*HelloWorld obj2=(HelloWorld) context.getBean("helloWorldBean");
		System.out.println(obj1.hashCode());
		System.out.println(obj1);
		System.out.println("-----------------------------");
		System.out.println(obj2.hashCode());
		System.out.println(obj2);*/
		
		((AbstractApplicationContext)context).registerShutdownHook();
	}

}
