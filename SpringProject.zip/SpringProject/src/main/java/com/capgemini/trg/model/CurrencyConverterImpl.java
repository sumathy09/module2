package com.capgemini.trg.model;

public class CurrencyConverterImpl implements CurrencyConverter {
	private double exchangeRate;

	public CurrencyConverterImpl() {

	}
	public CurrencyConverterImpl(double exchangeRate) {
		super();
		this.exchangeRate = exchangeRate;
	}

	public double getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}


	@Override
	public double dollarToRupee(double dollars) {
		// TODO Auto-generated method stub
		return dollars*this.exchangeRate;
	}

}
