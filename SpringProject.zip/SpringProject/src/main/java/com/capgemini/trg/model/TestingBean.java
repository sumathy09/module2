package com.capgemini.trg.model;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;

import org.springframework.beans.factory.DisposableBean;

public class TestingBean implements Initializable,DisposableBean {

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Cleanup after");
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		System.out.println("Initialization before ");
	}

}
