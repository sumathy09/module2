package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

 


import com.capgemini.trg.conf.HelloWorldConfiguration;
import com.capgemini.trg.model.HelloWorld;

public class HelloWorldConfig {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new AnnotationConfigApplicationContext(HelloWorldConfiguration.class);
		/*HelloWorld obj=(HelloWorld)context.getBean("helloWorld");
		System.out.println(obj.getMessage());*/
		HelloWorld obj1=(HelloWorld)context.getBean("hello");
		System.out.println(obj1.getMessage());
	}

}
