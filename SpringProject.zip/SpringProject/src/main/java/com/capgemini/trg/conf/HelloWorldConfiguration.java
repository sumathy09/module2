package com.capgemini.trg.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.trg.model.HelloWorld;

@Configuration
public class HelloWorldConfiguration {
	//default bean id is method name,helloWorld
//@Bean
	@Bean(name="hello")
public HelloWorld helloWorld(){
	return new HelloWorld();
}
}
