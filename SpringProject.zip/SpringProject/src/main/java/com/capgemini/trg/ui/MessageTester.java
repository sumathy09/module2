package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.Message;

public class MessageTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("message.xml");
		Message message=(Message) context.getBean("messageBean");
		System.out.println(message.getMessage1());
		System.out.println(message.getMessage2());
		System.out.println(message.getMessage3());
		//System.out.println(message.g);
	}

}
