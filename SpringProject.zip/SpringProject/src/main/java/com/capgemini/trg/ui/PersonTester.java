package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.Person;

public class PersonTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("person2.xml");
		Person person1 = (Person) context.getBean("personBean");
		System.out.println(person1.getAdharCardNumber());
		System.out.println(person1.getName());
		System.out.println(person1.getResidentialAddress().getHouseNumber());
		System.out.println(person1.getPermanentAddress().getHouseNumber());
	    ((AbstractApplicationContext)context).registerShutdownHook();
	}

}
