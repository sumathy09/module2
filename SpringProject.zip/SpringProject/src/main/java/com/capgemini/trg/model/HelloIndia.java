package com.capgemini.trg.model;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component
public class HelloIndia {
	//default:type driven injection
	//@Autowired
	
	//name driven injection
	/*@Autowired(required=false)
	@Qualifier(value="meaasgeBean")*/
	
	//alternate,using java ee annotation
	@Resource(name="messageBean")
private Message message;


public Message getMessage() {
	return message;
}

public void setMessage(Message message) {
	this.message = message;
}

}
